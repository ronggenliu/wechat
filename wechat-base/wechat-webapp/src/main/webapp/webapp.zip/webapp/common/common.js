function loadScript(url, callback){
    var script = document.createElement ("script")
    script.type = "text/javascript";
    if (script.readyState){ //IE
        script.onreadystatechange = function(){
            if (script.readyState == "loaded" || script.readyState == "complete"){
                script.onreadystatechange = null;
                callback();
            }
        };
    } else { //Others
        script.onload = function(){
            callback();
        };
    }
    script.src = url;
    document.getElementsByTagName("head")[0].appendChild(script);
}

/*
 * 
<script type="text/javascript" src="/wechat/static/js/common/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="/wechat/static/js/common/bootstrap.min.js"></script>
<script type="text/javascript" src="/wechat/static/js/common/jquery.easyui.min.js"></script>
<script type="text/javascript" src="/wechat/static/js/common/jquery.json-2.4.min.js"></script>
<script type="text/javascript" src="/wechat/static/js/common/ajaxData.js"></script>
<script type="text/javascript" src="/wechat/static/js/common/myEasyui.js"></script>
<script type="text/javascript" src="/wechat/static/js/common/form.js"></script>
<script type="text/javascript" src="/wechat/static/js/common/ace.min.js"></script>
<script type="text/javascript" src="/wechat/static/js/common/ace-elements.min.js"></script>
<script type="text/javascript" src="/wechat/static/js/thisPro/common.js"></script>

*/


document.write("<link rel='stylesheet' href='/wechat/static/css/bootstrap.css' />");
document.write("<link rel='stylesheet' href='/wechat/static/css/ace.css' />");
document.write("<link rel='stylesheet' href='/wechat/static/css/ace-rtl.min.css' />");
document.write("<link rel='stylesheet' href='/wechat/static/css/ace-skins.min.css' />");
document.write("<link rel='stylesheet' href='/wechat/static/css/font-awesome.css' />");
document.write("<link rel='stylesheet' href='/wechat/static/css/themes/metro/easyui.css' />");
document.write("<link rel='stylesheet' href='/wechat/static/css/icon.css' />");
document.write("<link rel='stylesheet' href='/wechat/static/css/color.css' />");
document.write("<link rel='stylesheet' href='/wechat/static/css/singleTabTemplate.css' />");

document.write("<script type='text/javascript' src='/wechat/static/js/common/jquery-1.11.2.min.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/bootstrap.min.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/jquery.easyui.min.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/easyui-lang-zh_CN.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/jquery.json-2.4.min.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/ajaxData.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/myEasyui.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/form.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/ace.min.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/ace-elements.min.js'></script>");
document.write("<script type='text/javascript' src='/wechat/static/js/common/ace-extra.min.js'></script>");

document.write("<script type='text/javascript' src='/wechat/static/js/thisPro/common.js'></script>");

//window.onload=function(){
//	var currentUrl = window.location.href;
//	if(currentUrl.indexOf("login.html")==-1||currentUrl.lastIndexOf("wechat/")==-1||currentUrl.lastIndexOf("wechat")==-1){
//		console.log(currentUrl);
//		
//	}
//	else{
//	}
//}



