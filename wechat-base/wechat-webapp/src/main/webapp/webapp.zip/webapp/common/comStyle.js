/*
 * 
<link rel="stylesheet" href="/psi/static/css/bootstrap.min.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/psi/static/css/ace.css" />
<link rel="stylesheet" href="/psi/static/css/ace-rtl.min.css" />
<link rel="stylesheet" href="/psi/static/css/ace-skins.min.css" />



<link rel="stylesheet" type="text/css" href="/psi/static/css/font-awesome.css"> 
<link id="themesLink" rel="stylesheet" type="text/css" href="/newmedia/static/css/themes/metro/easyui.css">
<link rel="stylesheet" type="text/css" href="/newmedia/static/css/icon.css">
<link rel="stylesheet" type="text/css" href="/newmedia/static/css/color.css">
<link rel="stylesheet" type="text/css" href="/psi/static/css/singleTabTemplate.css">
*/
function loadScript(url, callback){
    var script = document.createElement ("script")
    script.type = "text/javascript";
    if (script.readyState){ //IE
        script.onreadystatechange = function(){
            if (script.readyState == "loaded" || script.readyState == "complete"){
                script.onreadystatechange = null;
                callback();
            }
        };
    } else { //Others
        script.onload = function(){
            callback();
        };
    }
    script.src = url;
    document.getElementsByTagName("head")[0].appendChild(script);
}

//这个方法用于css加载不可取
function loadStyle(url, callback){
	var style = document.createElement ("link")
	style.rel = "stylesheet";
	if (style.readyState){ //IE
		style.onreadystatechange = function(){
			if (style.readyState == "loaded" || style.readyState == "complete"){
				style.onreadystatechange = null;
				callback();
			}
		};
	} else { //Others
		style.onload = function(){
			callback();
		};
	}
	style.href = url;
	document.getElementsByTagName("head")[0].appendChild(style);
}


document.write("<link rel='stylesheet' href='/psi/static/css/bootstrap.min.css' />");
document.write("<link rel='stylesheet' href='/psi/static/css/ace.css' />");
document.write("<link rel='stylesheet' href='/psi/static/css/ace-rtl.min.css' />");
document.write("<link rel='stylesheet' href='/psi/static/css/ace-skins.min.css' />");
document.write("<link rel='stylesheet' href='/psi/static/css/font-awesome.css' />");
document.write("<link rel='stylesheet' href='/psi/static/css/themes/metro/easyui.css' />");
document.write("<link rel='stylesheet' href='/psi/static/css/icon.css' />");
document.write("<link rel='stylesheet' href='/psi/static/css/color.css' />");
document.write("<link rel='stylesheet' href='/psi/static/css/singleTabTemplate.css' />");



/*
loadStyle("/psi/static/css/bootstrap.min.css", function(){ }); 
loadStyle("/psi/static/css/ace.css", function(){ }); 
loadStyle("/psi/static/css/ace-rtl.min.css", function(){ }); 
loadStyle("/psi/static/css/ace-skins.min.css", function(){ }); 
loadStyle("/psi/static/css/font-awesome.css", function(){ }); 
loadStyle("/psi/static/css/themes/metro/easyui.css", function(){ }); 
loadStyle("/psi/static/css/icon.css", function(){ }); 
loadStyle("/psi/static/css/color.css", function(){ }); 
loadStyle("/psi/static/css/singleTabTemplate.css", function(){ }); */



/*
loadScript("/psi/static/js/common/jquery-1.11.2.min.js", function(){  //调用  
 
}); 
loadScript("/psi/static/js/common/bootstrap.min.js", function(){  //调用  
	
}); 
loadScript("/psi/static/js/common/jquery.easyui.min.js", function(){  //调用  
	
}); 

loadScript("/psi/static/js/common/jquery.json-2.4.min.js", function(){  //调用  
	
}); 
loadScript("/psi/static/js/common/ajaxData.js", function(){  //调用  
	
}); 
loadScript("/psi/static/js/common/myEasyui.js", function(){  //调用  
	
}); 
loadScript("/psi/static/js/psi/common.js", function(){  //调用  
	
}); 
loadScript("/psi/static/js/common/ace.min.js", function(){  //调用  
	
}); 
loadScript("/psi/static/js/common/ace-elements.min.js", function(){  //调用  
	
}); 
loadScript("/psi/static/js/common/ace-extra.min.js", function(){  //调用  
	
}); */




