// 获取cookie的值
function getCookie(name) {
	
	var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
	if (arr = document.cookie.match(reg))
		return unescape(arr[2]);
	else
		return null;
}

// 设置时间，时间单位为秒，小时和天数
function getsec(str) {
	var str1 = str.substring(1, str.length) * 1;
	var str2 = str.substring(0, 1);
	if (str2 == "s") {
		return str1 * 1000;
	} else if (str2 == "h") {
		return str1 * 60 * 60 * 1000;
	} else if (str2 == "d") {
		return str1 * 24 * 60 * 60 * 1000;
	}
}
// 设置cookie 的值
function setCookie(name, value, time) {
	var strsec = getsec(time);
	var exp = new Date();
	var path = ";path=/"; // 路径 （/）表示网站根目录
	exp.setTime(exp.getTime() + strsec * 1);
	// alert(name + "="+ escape(value) + ";expires=" + exp.toGMTString() + path);
	document.cookie = name + "=" + escape(value) + ";expires=" + exp.toString() + path;

}

// 删除cookie
function deleteCookie(name) {
	var cookieVal = getCookie(name);
	var exp = new Date();
	exp.setTime(exp.getTime() - 1);

	console.log(exp.toString());
	console.log(exp.toGMTString());
	document.cookie = name + "=" + cookieVal + ";expires=" + exp.toString();
}