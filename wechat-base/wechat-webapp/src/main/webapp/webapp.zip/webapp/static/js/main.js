//datagridy演示根据查询条件显示分页
$(function() {
	$("#search").click(function() {
		$("#cusTable").datagrid({
			url : "/demo_web/datagrid?method=getList"
		});
		var queryParams = {
			name : "jason2",
			age : "28"
		};
		$("#cusTable").datagrid("options").queryParams = queryParams;

		$("#cusTable").datagrid("load");

	});

})

// 向前推N周 返回结果数组 0：当前周所在日期(type:0 周的第一天 type1周的最后一天) 索引2：所在第几周
function getWeekBefore(num, type) {
	var returnArray = [];

	var c_date = curDateTime();// 当前日期
	// var c_date = "2014-01-08";//当前日期
	var dateArr = c_date.split("-");// 拿到当前的 年、月
	// 当前日期所在周
	var c_week = getWeekNumberByDate(dateArr[0], dateArr[1], dateArr[2]);
	var date11 = new Date(dateArr[0], parseInt(dateArr[1]) - 1, dateArr[2]);
	// 当前日期所在周几？
	var c_DayWeek = date11.getDay() == 0 ? 7 : date11.getDay();// 当前日期所在周几

	var year = parseInt(dateArr[0]);
	// 当前1月1号所在周的天数和周几
	var date0 = new Date(year, 0, 1); // 当年的第一天年
	var oneDayWeek = date0.getDay() == 0 ? 7 : date0.getDay();// 当年的第一天是周几
	var oneWeekDay = 7 - oneDayWeek + 1; // 当年第一周所在的天数

	// 去年最后一周所在的天数
	var quyear = year - 1;
	var date1 = new Date(quyear, 11, 31); // 去年的最后一天
	var quDayWeek = date1.getDay() == 0 ? 7 : date1.getDay();// 去年的最后一天的所在周几
	var quweek = getWeekNumberByDate(quyear, 12, 31);

	// 确定推N周所在的周数 判断是否存在跨年
	var chaw = c_week - num;
	// 第一种情况 不跨年、不是第一周
	if (chaw > 1) {
		// 计算推的天数
		var chday = c_DayWeek + (num - 1) * 7;
		returnArray[0] = getDayBefore(c_date, chday);
	} else if (chaw == 1) {// 推到今年第一周
		returnArray[0] = year + "-01-01";
	} else if (chaw == 0) {// 去年最后一周
		var quyear = year - 1;
		returnArray[0] = quyear + "-12-31";
	} else if (chaw < 0) {// 跨年了
		// 先把今年推到头 第一周+本周+周-2*7
		var chday = 0;
		if (c_week != 1) {
			chday = c_DayWeek + (num - 2) * 7 + oneWeekDay; // 按照这个日期推 可以推到去年最后一天
		} else {
			chday = parseInt(dateArr[2]); // 按照这个日期推 可以推到去年最后一天
		}
		// 应该推到去年的所在周 去年最后一周的天数 再往前N-1周
		var chweekday = quDayWeek + (0 - chaw - 1) * 7 + chday;
		returnArray[0] = getDayBefore(c_date, chweekday);
	}

	// 需要返回的时间
	var returnDate = returnArray[0];
	var reArr0 = returnDate.split("-");// 拿到当前的 年、月
	// 本周第一天
	if (type == 0) {
		// 是否是第一个月
		if (chaw == 1) {
			returnArray[0] = reArr0[0] + "-01-01";
		} else if (chaw == 0) {// 是否是最后一个月
			// 去年最后一周的周几
			var dayend = 31 - parseInt(quDayWeek) + 1;
			returnArray[0] = reArr0[0] + "-12-" + dayend;
		} else {// 平常心
			var dayend = parseInt(reArr0[2]) - 6;
			dayend = dayend < 10 ? "0" + dayend : dayend;
			returnArray[0] = reArr0[0] + "-" + reArr0[1] + "-" + dayend;
		}
	} else if (type == 1) {
		if (chaw == 1) {
			var dayend = parseInt(oneWeekDay) < 10 ? "0" + oneWeekDay : oneWeekDay;
			returnArray[0] = reArr0[0] + "-01-" + dayend;
		}
	}
	var reArr1 = returnArray[0].split("-");
	// 拿到所在周
	returnArray[1] = getWeekNumberByDate(reArr1[0], reArr1[1], reArr1[2]);
	return returnArray;

}