


/*
 * 对easyui 的封装，使得操作更加简便
 */
 
 var initFormValue={};//作为修改时修改之前的表单对象，以作为对比是否修改
 function changeModel(checkbox){
		$('#dg_table').datagrid({singleSelect:(checkbox.checked)});
	$('#chooseModel').empty();
	if(checkbox.checked){
		$('#chooseModel').append("选择模式(<strong>单选</strong>)：");
	}
	else{
		$('#chooseModel').append("选择模式(<strong>多选</strong>)：");
	}
}
 function showAddDialog(){
   
	 $("#myModalLabel").text("添加");
        $("#dlg_form").get(0).reset();
        $("#dlg_form textarea").val("");
 }
 
 
 
 
 

 
 
 function showUpdateDialog(){
        var rowData = $("#dg_table").datagrid("getSelections");
        if (rowData.length != 1) {
            return alertTipMsg("请选择一行要修改的数据.");
        } else {
            $("#myModalLabel").text("修改");
            
            $("#dlg_form").form("clear");
            $("#dlg_form").form("load", rowData[0]);
            initFormValue=$("#dlg_form").serializeObject();
            
            return true;
        }
 }




// 对返回数据进行处理，使其显示提示信息
function doData(data, url) {
//	var tip = ajaxJsonStruts(data, url);
	
	var tip = ajaxJsonSpring(data, url);
	if(tip!=null){
		if (tip.status == "Y") {
			alertTipMsg(tip.msg);
			if(isValidObj($("#dg_table"))){
				$("#dg_table").datagrid("reload");
			}
			if(isValidObj($("#dg_table2"))){
				$("#dg_table2").datagrid("reload");
			}
			return true;
		} else if (tip.status == "N") {
			return alertTipMsg(tip.msg);
		} 
	}
//	else {
//		return alertTipMsg("操作失败！");;
//	}

}

//说明：添加和修改对于后台的操作都是一样，所以在前台的处理也是一样，仅用于struts2
//actionUrl:主Action的路径
function updateOrSave(url,flag){
        if(flag == "update"&&initFormValue){
            var changedData=$("#dlg_form").isFormChanged(initFormValue);//在ajaxData.js中，判断表单是否修改
            console.log(changedData);
            if (changedData.isChanged) {
            	delete changedData.isChanged;
            	doData($.toJSON(changedData),url);
            }
            else{
            	return alertTipMsg("您没有修改任何数据！");
            }
        }
        else{
        	 var data = $("#dlg_form").getFormJson();//springmvc传递的是json字符串
        	doData(data,url);
        }
        
}




//换肤
var themes = [
  			{value:'default',text:'Default',group:'Base'},
  			{value:'gray',text:'Gray',group:'Base'},
  			{value:'metro',text:'Metro',group:'Base'},
  			{value:'bootstrap',text:'Bootstrap',group:'Base'},
  			{value:'black',text:'Black',group:'Base'},
  			{value:'metro-blue',text:'Metro Blue',group:'Metro'},
  			{value:'metro-gray',text:'Metro Gray',group:'Metro'},
  			{value:'metro-green',text:'Metro Green',group:'Metro'},
  			{value:'metro-orange',text:'Metro Orange',group:'Metro'},
  			{value:'metro-red',text:'Metro Red',group:'Metro'},
  			{value:'ui-cupertino',text:'Cupertino',group:'UI'},
  			{value:'ui-dark-hive',text:'Dark Hive',group:'UI'},
  			{value:'ui-pepper-grinder',text:'Pepper Grinder',group:'UI'},
  			{value:'ui-sunny',text:'Sunny',group:'UI'}
  		];
//cb-theme为<select id="cb-theme" style="width:120px;"></select>
function addThemes(){
	
	$('#cb-theme').combobox({
		groupField:'group',
		data: themes,
		editable:false,
		panelHeight:'auto',
		onChange:onChangeTheme,
		onLoadSuccess:function(){
			$(this).combobox('setValue', 'metro-green');
		}
	});
}
function onChangeTheme(theme){
	var link = $('#themesLink');//css <link id="themesLink">
	link.attr('href', '/test/css/themes/'+theme+'/easyui.css');
}

/**
 * 格式化datagrid的text，设置性别显示格式
 */
function formatSex(value,row,index){
	 if(value=="1"){
		 return "男";
	 }
	 else if(value=="2"){
		 return "女";
	 }
	 else{
		 return value;
	 }
}

/**
 * 去掉时间后面的.0；
 * @param value
 * @param row
 * @param index
 * @returns
 */
function formatDateTime(value,row,index){
	if(isValidObj(value)){
		return value.substring(0,value.length-2);
	}
}

function formatWechatCert(value,row,index){
	if(value=="0"){
		return "未认证";
	}
	else if(value=="1"){
		return "已认证";
	}
}

function formatWechatType(value,row,index){
	if(value=="1"){
		return "订阅号";
	}
	else if(value=="2"){
		return "服务号";
	}
}
/**
 * 格式化datagrid的text，使得鼠标放上，能显示内容
 */
function formatText(value,row,index){
	if(value==null||value==""){
		return "";
	}
	return "<span title="+value+">"+value+"</span>";
}

//在layout的panle全局配置中,增加一个onCollapse处理title
//在layout的panle全局配置中,增加一个onCollapse处理title
$.extend($.fn.layout.paneldefaults, {
    onCollapse : function(){
        //获取layout容器
    	var layout = $(this).parents("body.layout");
	if(layout.length == 0) layout = $(this).parents("div.layout");
        //获取当前region的配置属性
        var opts = $(this).panel("options");
        //获取key
        var expandKey = "expand" + opts.region.substring(0, 1).toUpperCase() + opts.region.substring(1);
        //从layout的缓存对象中取得对应的收缩对象
        var expandPanel = layout.data("layout").panels[expandKey];
        //针对横向和竖向的不同处理方式
        if (opts.region == "west" || opts.region == "east") {
            //竖向的文字打竖,其实就是切割文字加br
        	if(opts && opts.title){
        		 var split = [];
                 for (var i = 0; i < opts.title.length; i++) {
                     split.push(opts.title.substring(i, i + 1));
                 }
                 if(expandPanel){
                      expandPanel.panel("setTitle", "&nbsp;");
                     expandPanel.panel("body").addClass("panel-title").css("text-align", "center").html(split.join("<br>"));
                 }
        	}
        } else {
        	if(expandPanel){
        		expandPanel.panel("setTitle", opts.title);
        	}
        }
    }
});

//格式化databox
$.fn.datebox.defaults.formatter = function(date){
	var y = date.getFullYear();
	var m = date.getMonth()+1;
	var d = date.getDate();
	return y+'-'+m+'-'+d;
};

//可编辑单元
$.extend($.fn.datagrid.methods, {
    editCell: function(jq,param){
        return jq.each(function(){
            var opts = $(this).datagrid('options');
            var fields = $(this).datagrid('getColumnFields',true).concat($(this).datagrid('getColumnFields'));
            for(var i=0; i<fields.length; i++){
                var col = $(this).datagrid('getColumnOption', fields[i]);
                col.editor1 = col.editor;
                if (fields[i] != param.field){
                    col.editor = null;
                }
            }
            $(this).datagrid('beginEdit', param.index);
            for(var i=0; i<fields.length; i++){
                var col = $(this).datagrid('getColumnOption', fields[i]);
                col.editor = col.editor1;
            }
        });
    }
});

var editIndex = undefined;
function endEditing(){
    if (editIndex == undefined){return true}
    if ($('#dg_table').datagrid('validateRow', editIndex)){
        $('#dg_table').datagrid('endEdit', editIndex);
        editIndex = undefined;
        return true;
    } else {
        return false;
    }
}
function onClickCell(index, field){
    if (endEditing()){
        $('#dg_table').datagrid('selectRow', index)
                .datagrid('editCell', {index:index,field:field});
        editIndex = index;
    }
};



//初始化easyui组件样式
$(function(){
	//国家化easyUI的datagrid样式
	
	/*$("#dg_table,#dg_table1,#dg_table2").datagrid({
	    onLoadSuccess:function(){
	    	var pager = $('#dg_table').datagrid('getPager');
	    	var icon2text = ["首页","上一页","下一页","尾页"];
	    	pager.pagination({
	    		beforePageText: '第',//页数文本框前显示的汉字
	    		afterPageText: '页    共 {pages} 页',
	    		displayMsg: '当前显示 {from} - {to} 条记录   共 {total} 条记录'
	    			
	    	});
	    	$(".pagination").find("td:eq(2),td:eq(3),td:eq(9),td:eq(10)").each(function(i){
	    		$(this).find(".l-btn-text").html(icon2text[i]);
	    	});
	    }
	});*/
	
	//截止日期不能小于起始日期
	$('#endDate').datebox({
		onSelect: function(date){
			var startDate = $('#startDate').datebox('getValue');
			var endDate = $('#endDate').datebox('getValue');
			if(startDate!=null&&startDate!=""){
				if(!compareDate(startDate,endDate)){//如果小于开始日期则，截止日期为开始日期
					$('#endDate').datebox('setValue', startDate);
				}
			}
		}
	});
	
	//起始日期不能大于截止日期
	$('#startDate').datebox({
		onSelect: function(date){
			var startDate = $('#startDate').datebox('getValue');
			var endDate = $('#endDate').datebox('getValue');
			if(endDate!=null&&endDate!=""){
				if(!compareDate(startDate,endDate)){//如果大于截止日期，则其值为截止日期
					$('#startDate').datebox('setValue', endDate);
				}
			}
		}
	});
	
	$(".easyui-datebox").datebox({editable:false,height:30});
	$(".easyui-datetimebox").datetimebox({editable:false,height:30});
	
	
});








