//及时预览图文效果，但必须填入图片路径
$("#preview").click(function(){
	var fmdata=$("#dlg_form").serializeObject();
	fmdata.picId=fmdata.picId.trim();
	var $newsItems=$("#newsItems");
//	data.picUrl=data.picUrl.trim();
	fmdata.pageUrl=fmdata.pageUrl.trim();
	if(!fmdata.pageUrl){
		fmdata.pageUrl="#";
	}
	if(fmdata.picId){
		//console.log(data.picUrl);
		var url="/wx-yx/resImage/getImageById.action?picId="+fmdata.picId;
		var data=ajaxGetData(url);
		if(data.length<1){
			 $.messager.show({
	               title : "提示",
	               msg : "请检查规则编号是否正确！",
	               timeout : 3000,
	               showType : "slide"
	           });
			 return false;
			 
		}
		var imgurl="\\wx-yx"+data.picUri.split("wx-yx")[1];
		//console.log(data);
//		console.log(imgurl);
		$("#newsItems").empty();//清空原来的显示
		var width=data.picW;
	
		//console.log(width);
		//如果图片高度大于300，则当做图文头部，否则当做图文列表
		var header="<div class='newsHeader'><a href='"+fmdata.pageUrl+"' target='_blank'>"+fmdata.title+"</a><img src='"+imgurl+"'/></div>";
		if(width>290){
			$newsItems.append(header);
		}
		else{
			$newsItems.append(header.replace(/newsHeader/,"newsList"));
		}
	
	}
	else{
		 $.messager.show({
               title : "提示",
               msg : "请输入图片路径！",
               timeout : 3000,
               showType : "slide"
           });
	}
});

$("#resetPreview").click(function(){
	$("#newsItems").empty();//清空原来的显示
});
//预览同一个规则的图文消息，需要填写图文规则编号
$("#previewAll").click(function(){
	
	var fmdata=$("#dlg_form").serializeObject();
	var $newsItems=$("#newsItems");
	fmdata.ruleResId=fmdata.ruleResId.trim();
	if(fmdata.ruleResId){
		
		var url="/wx-yx/wechatPushNews/getRuleNews.action?ruleResId="+fmdata.ruleResId;
		var data=ajaxGetData(url);
		if(data.length<1){
			 $.messager.show({
	               title : "提示",
	               msg : "请检查规则编号是否正确！",
	               timeout : 3000,
	               showType : "slide"
	           });
			 
		}
		else{
			$("#newsItems").empty();//清空原来的显示
			$.each(data,function(key,value){
//				console.log(value);
				var imgurl="\\wx-yx"+value.picUrl.split("wx-yx")[1];
				var width=value.picW;
				var header="<div class='newsHeader'><a href='"+value.pageUrl+"' target='_blank'>"+value.title+"</a><img src='"+imgurl+"'/></div>";
				if(width>290){
					$newsItems.append(header);
				}
				else{
					$newsItems.append(header.replace(/newsHeader/,"newsList"));
				}
				
			});
		}
	}
	else{
		$.messager.show({
                title : "提示",
                msg : "请输入图文规则！",
                timeout : 3000,
                showType : "slide"
            });
	}
	
});

//通过img对象来获取图片的原始宽高
function getImgInfoByImg(img, callback) {
	if(!img){
		return null;
	}
    var nWidth, nHeight;
    if (img.naturalWidth) { // 现代浏览器
        nWidth = img.naturalWidth;
        nHeight = img.naturalHeight;
    } else { // IE6/7/8
        var image = new Image();
        image.src = img.src;
        image.onload = function() {
            callback(image.width, image.height);
        }
    }
    return [nWidth, nHeight];
};

//通过src字符串来获取图片的原始宽高
function getImgInfoBySrc(src, callback) {
	if(!src){
		return null;
	}
	var image = new Image();
        image.src = src;
    var nWidth, nHeight;
    if (image.naturalWidth) { // 现代浏览器
        nWidth = image.naturalWidth;
        nHeight = image.naturalHeight;
    } else { // IE6/7/8
        image.onload = function() {
//        	nWidth=image.width;
//        	nHeight=image.height;
		//console.log(image.width);
            callback(image.width, image.height);
        }
    }
    return [nWidth, nHeight]
};