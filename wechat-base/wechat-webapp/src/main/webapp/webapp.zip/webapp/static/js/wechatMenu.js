var btnArr=new Array(),
groupArr=new Array();
//封装数组删除
Array.prototype.del=function(n) {//n表示第几项，从0开始算起。
//prototype为对象原型，注意这里为对象增加自定义方法的方法。
	if(n<0)return this;//如果n<0，则不进行任何操作。
	else return this.slice(0,n).concat(this.slice(n+1,this.length));//拼接数组，去掉n项
}
//根据菜单的可以来删除数组
function getArrObj(arr,key){
	for(var i=0;i<arr.length;i++){
		if(arr[i].key==key){
			return arr[i];
		}
	}
}
//根据菜单的可以来删除数组
function removeMenuByKey(arr,key){
	for(var i=0;i<arr.length;i++){
		if(arr[i].key==key){
			return arr.del(i);
		}
	}
}
//根据菜单的可以来删除数组
function removeGroupItemByKey(arr,key){
	for(var i=0;i<arr.length;i++){
		if(arr[i].groupId==key){
			arr= arr.del(i);
		}
	}
	return arr;
}
function resetMenuPage(){
	if($('#menuInfo li').length==0){
		$("#noBtnTip").removeClass("hide");
		$("#chooseAction").addClass("hide");
		$("#showGroupBtnTip").addClass("hide");
	}
}
//获取选中的菜单对象
function getIsSelected(){
	if(groupArr.length>0){
		for(var i=0;i<btnArr.length;i++){
			if(btnArr[i].isSelected){
				return btnArr[i];
			}
		}
		for(var i=0;i<groupArr.length;i++){
			if(groupArr[i].isSelected){
				return groupArr[i];
			}
		}
	}
	else{
		return alertTipMsg("请选择菜单选项！")
	}
}
//重置菜单对象的是否选中
function resetIsSelected(key){
	for(var i=0;i<btnArr.length;i++){
		if(btnArr[i].key==key){
			btnArr[i].isSelected=true;
		}
		else{
			btnArr[i].isSelected=false;
		}
	}
	for(var i=0;i<groupArr.length;i++){
		if(groupArr[i].key==key){
			groupArr[i].isSelected=true;
		}
		else{
			groupArr[i].isSelected=false;
		}
	}
}
//判断菜单对象是否已经存在，根据key
function isExsitedMenu(arr,key){
	for(var i=0;i<arr.length;i++){
		if(arr[i].key==key){
			return true;
		}
	}
	return false;
}

//给菜单按钮添加属性信息
function updateMenuInfo(arr,key,attr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i].key==key){
			if(attr=="groupId"){
				arr[i].groupId=value;
			}
			else if(attr=="btnName"){
				arr[i].btnName=value;
			}
			else if(attr=="btnType"){
				arr[i].btnType=value;
			}
			else if(attr=="content"){
				arr[i].content=value;
			}
			else if(attr=="hasChild"){
				arr[i].hasChild=value;
			}
			else if(attr=="groupName"){
				arr[i].groupName=value;
			}
		}
	}
	return arr;
}

$(function(){
	$("#sendMsg").click(function(){
		
		getIsSelected().btnType="click";
		console.log(btnArr);
	});
	$("#toPageUrl").click(function(){
		getIsSelected().btnType="view";
		console.log(groupArr);
	});
	
	$("#addGroup").click(function(){
		$('#noBtnTip').addClass("hide");
		$("#chooseAction").removeClass("hide");
		
//		return false;
		var obj={};
		var groupNum=$('#menuInfo').children("li").length;
		if(groupNum>=3){
			return alertTipMsg("菜单分组不能超过三个！");
		}
		var groupPos=groupNum+1;
		 var uuid=new UUID().toString();
		 var hrefId="group"+uuid;
		var groupHtml="<li class=\"list-group-item menu-group\" > <i class=\"pull-left blue glyphicon glyphicon-list\"></i>"
		groupHtml=groupHtml+"&nbsp;<a href=\"#"+hrefId+"\"  data-toggle=\"collapse\" class=\"nav-header hide\" >菜单组"+groupPos+"</a>";
		groupHtml=groupHtml+"<input type=\"text\" name=\""+uuid+"\" />"+getGroupIcon(1);
		groupHtml=groupHtml+"</li>";
		groupHtml=groupHtml+"<div id=\""+hrefId+"\"><ul  class=\"nav nav-stacked nav-list\" ></ul></div><hr>";
		
		$("#menuInfo").append(groupHtml);
		obj.groupName="添加";
		obj.key=uuid;
		obj.hasChild=false;
		groupArr.push(obj);
		$("li.menu-group input").focus();
	});
	
	 $('#menuInfo').on('mouseover',".list-group-item,.nav-item", function() {
		 $(this).find(".action-buttons").removeClass("hide");
	 })
	.on('mouseout',".list-group-item,.nav-item", function() {
		$(this).find(".action-buttons").addClass("hide");
	})
	 .on('blur',"li input", function(ev) {
		 ev.stopPropagation();
		 ev.preventDefault();
		 
		 var $this=$(this);
		 var val=$this.val();
		 var key=$this.attr("name");
		 
		 if(val.trim()=="")val="添加";
		 $this.addClass("hide");
		 if($this.prev("a").html()!=undefined){
//			console.log("修改组："+val);
			 if(getStrLength(val)>8){
				 val=val.substring(0, 4)+"…";
				 $this.prev("a").removeClass("hide").html(val);
				 groupArr=updateMenuInfo(groupArr,key,"groupName",val);
				 return alertTipMsg("一级菜单组不能超过4个汉字，或者8个字母")
			 }
			 groupArr=updateMenuInfo(groupArr,key,"groupName",val);
			 $this.prev("a").removeClass("hide").html(val);
			
		 }
		 else if($this.prev("span").html()!=undefined){
//			 console.log("修改按钮："+val);
			 if(getStrLength(val)>14){
				 val=val.substring(0, 7)+"…";
				 $this.prev("span").removeClass("hide").html(val);
				 btnArr=updateMenuInfo(btnArr,key,"btnName",val);
				 return alertTipMsg("二级子菜单不能超过7个汉字或者14个字母");
			 }
			 btnArr=updateMenuInfo(btnArr,key,"btnName",val);
			 $this.prev("span").removeClass("hide").html(val);
		 }
		
		
		
	 })
	 .on('click',".action-buttons a.updateBtn", function(ev) {
		 ev.stopPropagation();
		 ev.preventDefault();
			var $this=$(this);
			var $prev=$this.parent().prevAll("a,span");
//			console.log("updateObj:"+$prev);
			$prev.addClass("hide");
			var value=$prev.html();
			if($prev.children("span").html()){
				value=$prev.children("span").html();
			}
			$this.parent().prev("input").removeClass("hide").focus().val(value);
	 })
	.on('click',".action-buttons a.addItem", function(ev) {
		ev.stopPropagation();
		 ev.preventDefault();
			var $this=$(this);
			var hrefId=$this.parent().prevAll("a").attr("href").split("#")[1];
			var groupBtnNum=$("#"+hrefId+" ul").find("li").length;
			var key=hrefId.split("group")[1];
			getArrObj(groupArr,key).hasChild=true;
			var obj={};
			if(groupBtnNum>=5){
				return alertTipMsg("分组子菜单不能超过5个！");
			}
			var uuid=new UUID().toString();
			var btnItemHtml="<li class=\"nav-item menu-btn-item\" > <i class=\"pull-left glyphicon glyphicon-play\"></i>" +
					"&nbsp;<span></span><input type=\"text\" name=\""+uuid+"\"/>"+getGroupIcon(0)
			btnItemHtml=btnItemHtml+"</div></li>"
			$("#"+hrefId+" ul").append(btnItemHtml);
			obj.btnName="添加";
			obj.key=uuid;
			obj.groupId=key;
			btnArr.push(obj);
			$("li.menu-btn-item input").focus();
	 })
	 .on('click',".action-buttons a.removeItem", function(ev) {
		 ev.stopPropagation();
		 ev.preventDefault();
		 var $this=$(this);
			//console.log("remove");
			var childrenId=$this.parent().prevAll("a").attr("href");
			var key=$this.parent().prev("input").attr("name");
			if(childrenId){
				$.messager.confirm("提示信息", "确认删除整组菜单?", function(r) {
					if (r) {
						$("#"+childrenId.split("#")[1]).remove();
						$this.parent().parent("li").remove();
						groupArr=removeMenuByKey(groupArr,key);
						btnArr=removeGroupItemByKey(btnArr,key);
						resetMenuPage();
					} else {
						return false;
					}
				});
			}
			else{
				$this.parent().parent("li").remove();
				btnArr=removeMenuByKey(btnArr,key);
			}
//			console.log($('#menuInfo li').length);
			resetMenuPage();
	 })
	 .on('click',"li", function(ev) {
//		 ev.stopPropagation();
//		 ev.preventDefault();
//		 console.log("触发冒泡到li");
		 var $this=$(this);
		 $('#menuInfo li').removeClass("click-bg");
		 $this.addClass("click-bg");
		 var isBtnItem=$this.hasClass("menu-btn-item");
		 var isBtnGroup=$this.hasClass("menu-group");
		var key=$this.children("input").attr("name");
		resetIsSelected(key);//每次点击都要重置菜单选中属性
		
		 if(isBtnGroup){
			if(getArrObj(groupArr,key).hasChild){//如果有子菜单，则说明是菜单组
				$("#chooseAction").addClass("hide");
				$("#showGroupBtnTip").removeClass("hide");
			}
			else{//否则就是一个菜单按钮
				$("#chooseAction").removeClass("hide");
				$("#showGroupBtnTip").addClass("hide");
			}
		 }
		 else if(isBtnItem){//如果点击是子菜单选项
			 $("#chooseAction").removeClass("hide");
			$("#showGroupBtnTip").addClass("hide");
			
		 }
		 //console.log(getIsSelected());
		 
	 });
});

function getGroupIcon(isgroup){
	var bigger=100;
	var icon="<div class=\"pull-right action-buttons hide\">";
	if(isgroup==1){
		bigger=110;
		icon=icon+"<a class=\"green addItem\" href=\"javascript:void(0)\"><i class=\"glyphicon glyphicon-plus bigger-"+bigger+"\"></i></a>";
	}
	icon=icon+"<a class=\"blue updateBtn\" href=\"javascript:void(0)\"><i class=\"icon-pencil bigger-"+bigger+"\"></i></a>";
	icon=icon+"<a class=\"red removeItem\" href=\"javascript:void(0)\"><i class=\"icon-trash bigger-"+bigger+"\"></i></a>";
	icon=icon+"</div>";
	return icon;
}