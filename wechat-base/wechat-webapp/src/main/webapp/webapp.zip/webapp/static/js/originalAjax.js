function loadXMLDoc(url) {
	var xmlhttp;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.open("POST", url, false);// 同步
	xmlhttp.send();
	// console.log(xmlhttp.responseText);
	if (xmlhttp.responseText) {
		var jsonobj = eval('(' + xmlhttp.responseText + ')');
		return jsonobj;
	} else {
		alert("不好意思，数据异常！请刷新或者重新打开页面");
		return null;
	}
};

// 判断元素是否含有该样式类
function hasClass(elements, cName) {
	return !!elements.className.match(new RegExp("(\\s|^)" + cName + "(\\s|$)"));
};
// 在元素原有的基础上添加样式类
function addClass(elements, cName) {
	if (!hasClass(elements, cName)) {
		elements.className += " " + cName;
	}

};
// 在元素原有的基础上添加样式类
function removeClass(elements, cName) {
	if (hasClass(elements, cName)) {
		elements.className = elements.className.replace(new RegExp("(\\s|^)" + cName + "(\\s|$)"), " ");
	}

};
// 获取元素对象
function getObj(elemId) {
	return document.getElementById(elemId);
};
/**
 * 获取url？号后面的参数值，并转化为对象
 * file:///G:/html5/admin-manager/temp.html?name=dfadfa&id=123
 * Object {name: "dfadfa", id: "123"} 
 */
function urlGET() {
    var args = {};
    var search = decodeURIComponent(location.search.substring(1));
    var arr = search.split('&');
    for (var i = 0, len = arr.length; i < len; i++) {
        var t = arr[i].split('=');
        args[t[0]] = t[1];
    }
    return args;
}


/*
 * 由于浏览器的区别，elem.childNodes会有误差，所以要去除这种误差
 * 目的：为了在各个浏览器能获取到正确的之元素,对元素本身过滤
 * filterChildNodes(getObj("id");
 * var chils= s.childNodes; //得到s的全部子节点
var par=s.parentNode; //得到s的父节点
var ns=s.nextSbiling; //获得s的下一个兄弟节点
var ps=s.previousSbiling; //得到s的上一个兄弟节点
var fc=s.firstChild; //获得s的第一个子节点
var lc=s.lastChile; //获得s的最后一个子节点
 */
function filterChildNodes(elem) {
	var elem_child = elem.childNodes;
	for ( var i = 0; i < elem_child.length; i++) {
//		/\s/是非空字符在JS里的正则表达式。前面加！,则表示是空字符
		if (elem_child[i].nodeName == "#text" && !/\s/.test(elem_child.nodeValue)) {
//			当元素里面有节点类型是文本并且文本类型节点的节点值是空的。就把他删除。
			elem.removeChild(elem_child[i]);
		}
	}
	//return elem;
}

/**
 * 添加事件
 * @param node	 监听对象
 * @param type	 监听类型
 * @param listener	触发事件
 * @return	 事件是否添加成功
 * var share=getObj("share");
 * addEvent(share,"mouseout",startMove(-300));
 * addEvent(share,"mouseout",startMove);
 */
function addEvent(node, type, listener){
	if(node.addEventListener){
	  node.addEventListener(type, listener, false);
	  return true;
	} 
	else if(node.attachEvent){
	  node['e' + type + listener] = listener;
	  node[type + listener] = function(){
		  node['e' + type + listener](window.event);
	  };
	  node.attachEvent('on' + type, node[type + listener]);
	  return true;
	 }
	 return false;
};


