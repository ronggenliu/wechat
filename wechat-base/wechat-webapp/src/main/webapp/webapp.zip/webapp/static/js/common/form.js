function moveOption(e1, e2) {
	try {
		for (var i = 0; i < e1.options.length; i++) {
			if (e1.options[i].selected) {
				var e = e1.options[i];
				e2.options.add(new Option(e.text, e.value));
				e1.remove(i);
				i = i - 1;
			}
		}
		document.myform.listid.value = getvalue(document.myform.mySelected);
	} catch (e) {
	}
}
function getvalue(geto) {
	var allvalue = "";
	for (var i = 0; i < geto.options.length; i++) {
		allvalue += geto.options[i].value + ",";
	}
	return allvalue;
}
function moveAllOption(e1, e2) {
	try {
		for (var i = 0; i < e1.options.length; i++) {
			var e = e1.options[i];
			e2.options.add(new Option(e.text, e.value));
			e1.remove(i);
			i = i - 1;
		}
		document.myform.listid.value = getvalue(document.myform.mySelected);
	} catch (e) {

	}
}

function addOption(e) {

	var index = e.selectedIndex;
	var item = e.options[index];
	if (e.name == "oldPosSel") {
		document.myform.oldPos.value = item.text;
	} else if (e.name == "newPosSel") {
		document.myform.newPos.value = item.text;
	} else if (e.name == "oldDeptSel") {
		document.myform.oldDept.value = item.text;
	} else if (e.name == "newDeptSel") {
		document.myform.newDept.value = item.text;
	}
}

function validateEmail(value) {
	
	var re = /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/;
	return re.test(value);
	/*var apos = value.indexOf("@")
	var dotpos = value.lastIndexOf(".")
	var first = value.substring(0, 1);
	// 必须是字母开头，@和.号之间不能少于2个字符
	if (apos < 1 || dotpos - apos <= 2 || first <= 64 || first >= 91) {
		return false
	} else {
		return true
	}*/
}

function validateRePassword(obj1, obj2) {
	if (obj1.val() == obj2.val()) {
		return true;
	} else {
		return false;
	}
}

function isNum(value){
	for (var i = 0; i < value.length; i++) {
		var asciiNumber = value.substr(i, 1).charCodeAt();
		//console.log(asciiNumber);
		if (asciiNumber < 48 || asciiNumber > 57) {
			return alertTipMsg("亲，电话号码只能为数字哦！");
		}
	}
	return true;
}



function validateStrNum(value,minLength,maxLength){
	if(isNum(value)){
		if (value.length < minLength || value.length > maxLength) {
			return alertTipMsg("亲，电话号码的位数不对哦！");
		}
		return true;
	}
	else{
		return false;
	}
	
}

function validatePassword(obj) {
	if (isValidFormObj(obj)) {
		var value = obj.val();
		// var reg=/^[A-Za-z0-9]+$/;
		var numasc = 0;
		var charasc = 0;
		var char1=0;
		var invalidChar=0;

		if (value.length < 6 || value.length > 20) {
			return alertTipMsg("密码必须为6-15位的数字和字母及'_'的组合！");
		} 
		else {
			for (var i = 0; i < value.length; i++) {
				var asciiNumber = value.substr(i, 1).charCodeAt();
				if (asciiNumber >= 48 && asciiNumber <= 57) {
					numasc =numasc+ 1;
				}
				else if ((asciiNumber >= 65 && asciiNumber <= 90) || (asciiNumber >= 97 && asciiNumber <= 122)) {
					charasc =charasc+ 1;
				}
				else if(asciiNumber==95){
					char1=char1+1;
				}
				else{
					invalidChar=invalidChar+1;
				}
				// if ((asciiNumber >= 33 && asciiNumber <= 47)||(asciiNumber >= 58 && asciiNumber <= 64)||(asciiNumber >= 91 && asciiNumber <= 96)||(asciiNumber >= 123 && asciiNumber <= 126)) {
				// otherasc += 1;
				// }
			}
			if(invalidChar>0){
				return alertTipMsg("密码只能以英文字符和数字以及'_'组成");
			}
		}
	}
	else {
		return alertTipMsg("请输入密码！");
	}
	return true;
}

function getYearWeek(date) {
	var date2 = new Date(date.getFullYear(), 0, 1);
	var day1 = date.getDay();
	if (day1 == 0)
		day1 = 7;
	var day2 = date2.getDay();
	if (day2 == 0)
		day2 = 7;
	d = Math.round((date.getTime() - date2.getTime() + (day2 - day1) * (24 * 60 * 60 * 1000)) / 86400000);
	if(new Date().getTime()-date.getTime()<10000){//如果是直接date =new Date(),相差不会超过10秒，否则就按下面的算
		
		return Math.ceil(d /7);   
	}
	else{
		return Math.ceil(d /7)+1;
	}
}

//改变对象返回值
function getQryCondi(obj, returnValue) {
	if (obj == "" || obj == null || obj == undefined) {
		return returnValue;
	}
	return obj;
}


/**
 * obj doc node，一般用于验证表单是内容是否有效
 */
function isValidFormObj(obj) {
	if (obj.val() == null || obj.val() == "" || obj.val() == undefined) {
		return false;
	}
	return true;
}
// 一般用于判断页面是否存在该对象
function isValidObj(obj) {
	if (obj == null || obj == undefined||obj=="") {
		return false;
	}
	return true;
}
/**
 * 判断字符串长度
 */
function getStrLength(val) {
	var str = new String(val);
	var bytesCount = 0;
	for ( var i = 0, n = str.length; i < n; i++) {
		var c = str.charCodeAt(i);
		if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
			bytesCount += 1; // 如果是字母就+1
		} else {
			bytesCount += 2; // 如果你是汉字就+2
		}
	}
	return bytesCount;
}
// 将一个表单的数据返回成JSON对象,obj to json
$.fn.getFormJson = function() {
	return $.toJSON(this.serializeObject());
};

$.fn.serializeObject = function() {
	var o = {};
	var a = this.serializeArray();
	$.each(a, function() {
		if (o[this.name]) {
			if (!o[this.name].push) {
				o[this.name] = [ o[this.name] ];
			}
			o[this.name].push(this.value || '');
		} else {
			o[this.name] = this.value || '';
		}
	});
	return o;
};

function IsValidMobileNo(MobileNo) 
{ 
	var reg= /^[1][34578]\d{9}$/;
	//console.log("mobile:"+reg.test(MobileNo));
	return reg.test(MobileNo); 
}

function isValidTeleNo(teleNo){
	regexp= /^0\d{2,3}-?\d{7,8}$/;
	//console.log("teleNo:"+regexp.test(teleNo));
	return regexp.test(teleNo); 
}

$.fn.isFormChanged = function(initFormValue) {
	var changedData={};
	var newFormValue = this.serializeObject();
	changedData.isChanged = false;
	$.each(newFormValue, function(newKey, newVal) {
		if($("#"+newKey).attr("class")=="hide"){
			changedData[newKey]=newVal;
		}
		else{
			$.each(initFormValue, function(key, val) {
				if (newKey == key) {
					if (newVal != val) {
						changedData[newKey]=newVal;
						changedData.isChanged=true;
					}
				}
			});
		}
	});
//	console.log(changedData);
	return changedData;
};



// ajax添加select数据//数据必须是json,list型的
$.fn.mySelect = function(urlOrData, val, text) {
	var $this = $(this);
	var data = null;
	if ((typeof urlOrData) == "string") {
		data = ajaxGetData(urlOrData);
	} else {
		data = urlOrData;
		// console.log(data);
	}
	$this.data = data;
	$this.empty();
	$this.append("<option value=\"\">请选择</option>");
//	 console.log(data.length);
	
	if (null != data) {
		
		if (data.length == undefined) {// 如果发过来的数据直接是key-value，一般后台是map，则直接key value
			$.each(data, function(key, value) {
				$this.append("<option value=" + key + ">" + value + "</option>");
			});
		} 
		else {// 如果发过来的数据直接是是object数组，则一般后台都是list发过来的数据
			 
			$.each(data, function(key, value) {
				$this.append("<option value=" + value[val] + ">" + value[text] + "</option>");
			});
		}
	}
	return $this;
}


/**
 * 比较日前大小，如果开始日期sdate 大于截止日期edate，则返回false
 */
function compareDate(sdate,edate) {
	var arys = new Array();
	var arye = new Array();
	arys = sdate.split('-');
	arye = edate.split('-');
	// 这种比较也可以自定义两者比较
	var sdate2 = new Date(arys[0], parseInt(arys[1] - 1), arys[2]);
	var edate2 = new Date(arye[0], parseInt(arye[1] - 1), arye[2]);
	if (sdate2 > edate2) {
		return false;
	} else {
		return true;
	}
};

/**
 * 比较日前大小，如果大于等于当前日期，则返回true，否则返回false 这不比较时间，所以比较对象必须同格式，即将时间部分清0 
 * var sdate = new Date(arys[0], parseInt(arys[1] - 1), arys[2]); 
 * var edate = new Date(year, month, day);
 */
function compareDateWithToday(checkDate) {
	var arys = new Array();
	var date = new Date();// 获取当前时间
	var year = date.getFullYear(); // 获取完整的年份(4位,1970-????)
	var month = date.getMonth(); // 获取当前月份(0-11,0代表1月)
	var day = date.getDate();
	arys = checkDate.split('-');
	// 这种比较也可以自定义两者比较
	var sdate = new Date(arys[0], parseInt(arys[1] - 1), arys[2]);
	var edate = new Date(year, month, day);
	// console.log(edate.getFullYear());
	// console.log(edate);

	if (sdate < edate) {
		return false;
	} else {
		return true;
	}
};

/**
 * 只比较时间不比较日期，所以日期可以自定义为当前时间 比较时间大小，
 * 如果大于当前时间，则返回true，否则返回false new Date();默认包含时间
 */
function compareTimeWithNow(checkTime) {
	var arys = new Array();
	var date = new Date();// 获取当前时间
	var year = date.getFullYear(); // 获取完整的年份(4位,1970-????)
	var month = date.getMonth(); // 获取当前月份(0-11,0代表1月)
	var day = date.getDate();
	arys = checkTime.split(":");
	var stime = new Date(year, month, day, arys[0], arys[1]);
	// var etime = new Date();
	// console.log(etime);
	if (stime <= date) {
		return false;
	} else {
		return true;
	}
};

/**
 * 根据日期来获取所在的周数
 * @param date
 */
function getYearWeek(date) {
	var date2 = new Date(date.getFullYear(), 0, 1);
	var day1 = date.getDay();
	if (day1 == 0)
		day1 = 7;
	var day2 = date2.getDay();
	if (day2 == 0)
		day2 = 7;
	d = Math.round((date.getTime() - date2.getTime() + (day2 - day1) * (24 * 60 * 60 * 1000)) / 86400000);
	if(new Date().getTime()-date.getTime()<10000){//如果是直接date =new Date(),相差不会超过10秒，否则就按下面的算
		
		return Math.ceil(d /7);   
	}
	else{
		return Math.ceil(d /7)+1;
	}
}

//设置当前时间
function getCurrentTime() {
	var weeks = [ '星期天', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六' ];
	var date = new Date();
	var year = date.getFullYear(); // 获取完整的年份(4位,1970-????)
	var month = date.getMonth() + 1; // 获取当前月份(0-11,0代表1月)
	var day = date.getDate();
	var miu = date.getMinutes() > 9 ? date.getMinutes() : '0' + date.getMinutes();
	return year + "年" + (month) + "月" + day + "日   第" +getYearWeek(new Date())+"周   "+ weeks[date.getDay()] + " " + date.getHours() + ":" + miu;
}