//公共代码，用于发送和接受json数据,注意pageData必须是json对象
function ajaxJson(pageData, actionURI) {
	var d = null;
	// 如果是在具体项目中，则在此加上项目名称，这样actionURI就只需写action的相对路径
	// actionURI = "/CRM/" + actionURI;
	$.ajax({
		type : "POST",
		url : actionURI,
		data : (pageData),
		dataType : "json",
		async : false,
		success : function(data) {
			if (data) {
				if (data.status == "N") {
					alertTipMsg(data.msg)
				} else {
					d = data;
				}
			}
		},
		error : function(data) {
			if (data.status == 200) {
				alertTipMsg("请求成功，但是没有得到系统回应！");
			} else {
				alertTipMsg("ajax error!数据异常!请刷新页面！");
			}
		}
	});
	return d;
};



// springmvc ajxa 传对象并获得返回,注意pageData必须是json字符串
function ajaxJsonSpring(pageData, conUrl) {
	var d = null;
	// var cType="application/x-www-form-urlencoded; charset=UTF-8";
	$.ajax({
		type : "POST",
		contentType : "application/json; charset=utf-8",
		url : conUrl,
		cache : false,
		data : (pageData),
		dataType : "json",
		async : false,
		success : function(data) {
			if (data) {
				if (data.status == "N") {
					alertTipMsg(data.msg);
				} else {
					d = data;
				}
			}
		},
		error : function(data) {
			if (data.status == 200) {
				alertTipMsg("请求成功，但是没有得到系统回应！");
			} else {
				alertTipMsg("ajax error!数据异常!请刷新页面！");
			}
		}
	});
	return d;
};

function ajaxFile(pageData, conUrl) {
	var d = null;
	// var cType="application/x-www-form-urlencoded; charset=UTF-8";
	$.ajax({
		type : "POST",
		contentType : false,
		processData : false,
		url : conUrl,
		cache : false,
		data : (pageData),
		dataType : "json",
		async : false,
		success : function(data) {
			if (data) {
				if (data.status == "N") {
					alertTipMsg(data.msg);
				} else {
					d = data;
				}
			}
		},
		error : function(data) {
			if (data.status == 200) {
				alertTipMsg("请求成功，但是没有得到系统回应！");
			} else {
				alertTipMsg("ajax error!数据异常!请刷新页面！");
			}
		}
	});
	return d;
};

// 必须加上 async: false,否则执行顺序会发生改变，而得不到想要的数据
// ajax默认是异步执行的
function ajaxGetData(conUrl,method) {
	var d = null;
	var methodType="post"
	if(method){
		methodType=method;
	}
	$.ajax({
		type : methodType,
		url : conUrl,
		dataType : "json",
		async : false,
		success : function(data) {
			if (data) {
				if (data.status == "N") {
					alertTipMsg(data.msg);
				} else {
					d = data;
				}
			}
		},

		error : function(data) {
			console.log(data);
			if (data.status == 200) {
				alertTipMsg("请求成功，但是没有得到系统回应！");
//				d=data;
			} else {
				alertTipMsg("ajax error!数据异常!请刷新页面！");
			}
		}
	});
	// console.log(d);
	return d;
};

function ajaxGetData2(conUrl, type) {
	var d = null;
	$.ajax({
		type : type,
		url : conUrl,
		dataType : "json",
		async : false,
		success : function(data) {
			if (data) {
				if (data.status == "N") {
					alertTipMsg(data.msg);
				} else {
					d = data;
				}
			}
		},
		error : function(data) {
			if (data.status == 200) {
				alertTipMsg("请求成功，但是没有得到系统回应！");
			} else {
				alertTipMsg("ajax error!数据异常!请刷新页面！");
			}
		}
	});
	// console.log(d);
	return d;
};

// $("#btnSave").click(function(){
// var fileObj=$("#fileupload");
// var url="/wx-admin/sys/init/updateTextMenu.action";
// if(fileObj.val()!=""){
// ajaxSendFile(url, fileObj);
// }
// });
function ajaxSendFile(url, obj) {
	if (obj == null || obj == undefined) {
		return false;
	}
	var data = new FormData();
	$.each(obj.prop("files"), function(k, v) {
		data.append("file", v);// 单个文件的话，后台要用MultipartFile file数组接收！注意名字要对应起来
		// data.append("files", v);//多个文件的话，后台要用MultipartFile[] files数组接收
	});
	$.ajax({
		type : "POST",
		contentType : false,
		url : url,
		cache : false,
		data : (data),
		async : false,
		processData : false,
		success : function(data) {
			alertTipMsg("上传成功");
		},
		error : function(data) {
			alertTipMsg("上传失败");
		}
	});
}

function alertTipMsg(message) {
	if($.messager){
		$.messager.show({
			title : "提示",
			msg : message,
			timeout : 3000,
			showType : "slide",
			style : {
				zindex : 1000,
				top : document.body.scrollTop + document.documentElement.scrollTop,
				right : '',
				bottom : ''
			}
		
		});
	}
	else{
		alert(message);
	}
	return false;
};

/**
 * 获取url？号后面的参数值，并转化为对象
 * file:///G:/html5/admin-manager/temp.html?name=dfadfa&id=123
 * Object {name: "dfadfa", id: "123"} 
 */
function urlGET() {
    var args = {};
    var search = decodeURIComponent(location.search.substring(1));
    var arr = search.split('&');
    for (var i = 0, len = arr.length; i < len; i++) {
        var t = arr[i].split('=');
        args[t[0]] = t[1];
    }
    return args;
}


