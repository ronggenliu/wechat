function checkImgCode(inputCode){
	 var url="/newmedia/sys/checkCode.action?inputCode="+inputCode;
	 var data=ajaxGetData(url);
	 if(data!=null)return true;
	 else return false;
 }
function getImgCode(){
	var $imgCode=$("#imgCode");
	// var src = $imgCode.attr("src");
	 var src = "/newmedia/sys/getCode.action";
	 
	 $imgCode.attr("src", changeUrl(src));  
}

//时间戳     
//为了使每次生成图片不一致，即不让浏览器读缓存，所以需要加上时间戳     
function changeUrl(url) {  
  var timestamp = (new Date()).valueOf();  
  url = url.substring(0, 28);
  if ((url.indexOf("&") >= 0)) {  
      url = url + "&tamp=" + timestamp;  
  } else {  
      url = url + "?timestamp=" + timestamp;  
  }  
  return url;  
}  
 
function checkLogin(){
	if($("#userName").val().trim()==""){
		alertTipMsg("用户名不能为空！");
		return false;
	}
	if($("#password").val().trim()==""){
		alertTipMsg("密码不能为空！");
		return false;
	}
	data=$('#loginform').getFormJson();

	var url="/newmedia/login/checkLogin.action";

	result=ajaxJsonSpring(data,url);
	if(result!=null){
		window.location="/newmedia/pages/admin/index.html";
		
	}

}

function showCheckCodeStyle(flag){
	var $this=$("#checkCode");
	 var inputCode=$this.val();
	if(!checkImgCode(inputCode)){
		return false;
	}
	else{
		$this.css({"border":"solid green 2px"});
	}
}

$(document).ready(function(){


	getImgCode();
//	 $("#isRemb").css({"display":"block"});
	var cookies=document.cookie.split(";")
	 if(cookies.length>0){
		 $datalist=$("#userList");
		 var username=null;
		 for(var i=0;i<cookies.length;i++){
			 username=cookies[i].split("=")[1];
//			 console.log(cookies[i].indexOf("login"));
			 if(cookies[i].indexOf("login")>-1){
				 $datalist.append("<option value="+username+"/>");
			 }
		 }
		 $("#rembpwd").attr("checked","true");
		 $("#isRemb").val("1");
	 }
	

	
	
	$("#btn-login").click(function(){
		checkLogin();
	});
	
	
	$('#loginform').find('input').on('keyup',function(event){
		if(event.keyCode == 13){
			checkLogin();
		}
	});
	

	$("#rembpwd").click(function(){
		var value=$("#isRemb").val();
		if(value=="1"){
//			$this.removeAttr("checked");
			$("#isRemb").val("0");
			
		}
		else{
//			$this.attr("checked","true");
//			$this.val("1");
			$("#isRemb").val("1");
		}
		
	});
	
	 $("#checkCode").blur(function(){
		 showCheckCodeStyle();
	 }).keyup(function(){
		 //console.log($(this).val().length);
		 if($(this).val().length==4){
			 showCheckCodeStyle();
		 }
		 if($(this).val().length==0){
			 $(this).css({"border":"solid green 0.1px"});
		 }
	 });
	 
	 $("#imgCode").click(function(){
		 $("#checkCode").val("");
		 getImgCode();
		 $("#checkCode").css({"border":"solid red 0.1px"});
	 });
	 
    
});