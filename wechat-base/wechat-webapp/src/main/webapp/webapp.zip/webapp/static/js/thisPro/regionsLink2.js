/*
 * 三级联动
 */
//var $province = $("select[name='province']"),
// $city = $("select[name='city']"),
// $region = $("select[name='region']"),
var $province = $('#province2'),
    $city = $('#city2'),
    $region = $('#region2'),
    option = '<option>请选择</option>';

$city.disabled = 'disabled';
$region.disabled = 'disabled';
// console.log("regions:"+regions);
// 将option内容改为省名称和对应的id
$.each(regions, function (i, t) {
    option += '<option value=' + t.region_id + '>' + t.region_name + '</option>';
// console.log("region_id:"+t.region_id+"\tregion_name"+t.region_name);
});
$(option).appendTo($province);// 添加到省select下面

$('select').change(function () {
    var _this = $(this),
        name = _this.attr('name'),// 获取相应的select名
        region_id = _this.val(),
        next = _this.attr('data'),
        $next = $('select[name="' + next + '"]');
  // console.log("next:"+next);
    if (name == 'province') {
        $city.empty();
        $region.empty();
        $city.disabled = '';
    } else if (name == 'city') {
    	 $region.empty();
        $region.disabled = '';
    }
    var option = addressLinkage(region_id);
    $(option).appendTo($next);
 // 北京 、上海 、天津 、重庆 、港澳台没有市，所以要重新规划
    if (region_id == 2 || region_id == 25 || region_id == 27 || region_id == 32 || region_id == 34 ||region_id == 35 || region_id == 33)
    {
        $.each(regions, function (i, t) {
            if (t.region_id == region_id) {
                $city.val(t.children[0].region_id);
                var option = addressLinkage(t.children[0].region_id);
                $(option).appendTo($('select[name=region]'));
                if (t.children[0].region_name == t.children[0].children[0].region_name) {
                    $region.val(t.children[0].children[0].region_id);
                }
                return false;
            }
        });
    }
});

function addressLinkage(region_id) {
    var option = '<option>请选择</option>';
 // console.log("region_id:"+region_id);
    $.each(regions, function (i, p) {
        if (p.parent_id == region_id) {
            option += '<option value=' + p.region_id + '>' + p.region_name + '</option>';
        }
        $.each(p.children, function (i, c) {
            if (c.parent_id == region_id) {
                option += '<option value=' + c.region_id + '>' + c.region_name + '</option>';
            }
            $.each(c.children, function (i, a) {
                if (a.parent_id == region_id) {
                    option += '<option value=' + a.region_id + '>' + a.region_name + '</option>';
                }
            })
        })
    })
 // console.log("option:"+option);
    return option;
}

function getAddressStr(id) {
    var str = '';
    $.each(regions, function (i, p) {
        if (p.region_id == id) {
            str = p.region_name;
        }
        $.each(p.children, function (i, c) {
            if (c.region_id == id) {
                str = c.region_name;
            }
            $.each(c.children, function (i, a) {
                if (a.region_id == id) {
                    str = a.region_name;
                }
            })
        })
    });
    return str;
}
function setAdds(a, b, c) { /* 省市县ID */
    for (var i = 0, leni = regions.length; i < leni; i++) {
        if (regions[i].region_id == a) {
            setAdds.provinceEl.children.item(+a - 1).selected = true;
            for (var j = 0, lenj = regions[i].children.length; j < lenj; j++) {
                if (regions[i].children[j].region_id == b) {
                    addCity('city', regions[i].children, b);
                    for (var k = 0, lenk = regions[i].children[j].children.length; k < lenk; k++) {
                        if (regions[i].children[j].children[k].region_id == c) {
                            addCity('region', regions[i].children[j].children, c);
                        }
                    }
                }
            }
        }
    }
}
setAdds.provinceEl = document.getElementById('province');
setAdds.cityEl = document.getElementById('city');
setAdds.areaEl = document.getElementById('region');
function addCity(c, data, id) {
    setAdds[c + 'El'].innerHTML = '';
    for (var i = 0, len = data.length; i < len; i++) {
        var o = document.createElement('option');
        o.innerHTML = data[i].region_name;
        o.value = data[i].region_id;
        if (data[i].region_id == id) {
            o.selected = true;
        }
        setAdds[c + 'El'].appendChild(o);
    }
}