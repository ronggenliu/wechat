
/**
 * 比较日前大小，如果大于等于当前日期，则返回true，否则返回false 这不比较时间，所以比较对象必须同格式，即将时间部分清0 
 * var sdate = new Date(arys[0], parseInt(arys[1] - 1), arys[2]); 
 * var edate = new Date(year, month, day);
 */
function compareDateWithToday(checkDate) {
	var arys = new Array();
	var date = new Date();// 获取当前时间
	var year = date.getFullYear(); // 获取完整的年份(4位,1970-????)
	var month = date.getMonth(); // 获取当前月份(0-11,0代表1月)
	var day = date.getDate();
	arys = checkDate.split('-');
	// 这种比较也可以自定义两者比较
	var sdate = new Date(arys[0], parseInt(arys[1] - 1), arys[2]);
	var edate = new Date(year, month, day);
	// console.log(edate.getFullYear());
	// console.log(edate);

	if (sdate < edate) {
		return false;
	} else {
		return true;
	}
};

/**
 * 只比较时间不比较日期，所以日期可以自定义为当前时间 比较时间大小，
 * 如果大于当前时间，则返回true，否则返回false new Date();默认包含时间
 */
function compareTimeWithNow(checkTime) {
	var arys = new Array();
	var date = new Date();// 获取当前时间
	var year = date.getFullYear(); // 获取完整的年份(4位,1970-????)
	var month = date.getMonth(); // 获取当前月份(0-11,0代表1月)
	var day = date.getDate();
	arys = checkTime.split(":");
	var stime = new Date(year, month, day, arys[0], arys[1]);
	// var etime = new Date();
	// console.log(etime);
	if (stime <= date) {
		return false;
	} else {
		return true;
	}
};

/**
 * 根据日期来获取所在的周数
 * @param date
 */
function getYearWeek(date) {
	var date2 = new Date(date.getFullYear(), 0, 1);
	var day1 = date.getDay();
	if (day1 == 0)
		day1 = 7;
	var day2 = date2.getDay();
	if (day2 == 0)
		day2 = 7;
	d = Math.round((date.getTime() - date2.getTime() + (day2 - day1) * (24 * 60 * 60 * 1000)) / 86400000);
	if(new Date().getTime()-date.getTime()<10000){//如果是直接date =new Date(),相差不会超过10秒，否则就按下面的算
		
		return Math.ceil(d /7);   
	}
	else{
		return Math.ceil(d /7)+1;
	}
}

//设置当前时间
function getCurrentTime() {
	var weeks = [ '星期天', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六' ];
	var date = new Date();
	var year = date.getFullYear(); // 获取完整的年份(4位,1970-????)
	var month = date.getMonth() + 1; // 获取当前月份(0-11,0代表1月)
	var day = date.getDate();
	var miu = date.getMinutes() > 9 ? date.getMinutes() : '0' + date.getMinutes();
	return year + "年" + (month) + "月" + day + "日   第" +getYearWeek(new Date())+"周   "+ weeks[date.getDay()] + " " + date.getHours() + ":" + miu;
}

