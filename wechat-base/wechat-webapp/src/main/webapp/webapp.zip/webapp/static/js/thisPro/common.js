
/**
 * 加载头像上面的下拉按钮
 */
function loadUserMenu(){
	$userMenu=$("#userMenu");
	$userMenu.append(" <li><a id=\"userInfo\" href=\"/wechat/pages/admin/userInfoUpdate.html\"> <i class=\"icon-user\"></i> 个人资料</a></li>");
	$userMenu.append(" <li class=\"divider\"></li>");
	$userMenu.append("<li><a href=\"javascript:void(0)\" id=\"logout\"> <i class=\"icon-off\"></i> 退出</a></li>");
	$userMenu.append("");
	$userMenu.append("");
       
}
/**
 * 获取菜单数据，这个数据会根据登陆者的session显示相关的菜单
 */
function getMenu() {
	var url = "/wechat/sys/init/getMenu.action";
	var data = ajaxGetData(url);
	console.log(data);
	return data;
}
/**
 * 初始化页面菜单，每一次刷新页面都会初始化一次
 */
function initMenu() {
	var data = getMenu();
	if(data==null){
		return false;
	}
	var $sysMenuNav = $("#sysMenuNav");//导航内部
	var $breadBar = $("#breadBar");//导航标签样式
	var currentUrl = window.location.href;// 当前页面的全路径
	var isNewGroup = 0;
	var group = "";// level=2的菜单内容
	var menuItem = "";// level=1的菜单内容
	var last = data.length - 1;// 用来判断是否到了第一个each最后一条
	var breadBar = "";// 导航条
	var indexName = "";// 首页名称，方便显示导航条
//	 console.log(data);
	$sysMenuNav.empty();
	$breadBar.empty();
	// $breadBar.html("");
	// $sysMenuNav.html("");
	var lastParent = null;
	var tempGroup = "";
	$.each(data, function(key, value) {
		var level = value.level;//获取菜单等级
		var url = value.url;//获取菜单链接
		if (level == 1) {
			// console.log("level1"+value);
			menuItem = menuItem + "<li id=\"" + value.menuId + "\"> <a href=\"" + url + "\">";
			menuItem = menuItem + " <i class=\"" + value.classStyle + "\"></i> <span class=\"menu-text\">" + value.name + "</span></a></li>";
			if (url.indexOf("index.html") > -1) {
				$sysMenuNav.append(menuItem);
				menuItem = "";
				indexName = value.name;
			}
		}
		else if (level == 2) {
//			console.log("menuId:"+value.menuId);

			if (isNewGroup == 0) {
				group = "<li id=\"" + value.parent.menuId + "\"> <a href=\"#\" class=\"dropdown-toggle\">";
				group = group + "<i class=\"" + value.parent.classStyle + "\"></i><span class=\"menu-text\"> " + value.parent.name + "</span><b class=\"arrow icon-angle-down\"></b></a>";
				group = group + "<ul class=\"submenu\">";
				group = group + tempGroup;
				lastParent = value.parent.menuId;
				// console.log("level2:"+value.parent.name);
			}
			tempGroup = "<li id=\"" + value.menuId + "\"><a href=\"" + url + "\"><i class=\"" + value.classStyle + "\"></i>" + value.name + "</a></li>";
			if (value.parent.menuId != lastParent) {
				// console.log("level2:"+data[key+1].level);
				isNewGroup = 0;
				group = group + "</ul></li>";
				$sysMenuNav.append(group);
				if (data[key + 1].level == 1) {
					group = "<li id=\"" + value.parent.menuId + "\"> <a href=\"#\" class=\"dropdown-toggle\">";
					group = group + "<i class=\"" + value.parent.classStyle + "\"></i><span class=\"menu-text\"> " + value.parent.name + "</span><b class=\"arrow icon-angle-down\"></b></a>";
					group = group + "<ul class=\"submenu\">";
					group = group + tempGroup;
				}
			} else {
				group = group + tempGroup;
				isNewGroup = 1;

			}

		}

		if (key == last) {
			// console.log("key"+key);
			group = group + "</ul></li></li>";
			$sysMenuNav.append(group);// 添加最后一组菜单
			$sysMenuNav.append(menuItem);// 所有一级菜单，除了主页，都放在最下面

		}
	});
//	 console.log($sysMenuNav.html())
	// 给当前显示的页面添加导航样式
	$.each(data, function(key, value) {
		var level = value.level;
		var url = value.url;
		if (currentUrl.indexOf(url) > -1) {
			// console.log(value.menuId);
			$("#" + value.menuId).addClass("active");
			if (level == 1) {
				if (currentUrl.indexOf("index.html") > -1) {
					breadBar = "<li><i class=\"icon-home home-icon\"></i><a href=\"#\">" + value.name + "</a></li>";
					$breadBar.append(breadBar);

				} else if (currentUrl.indexOf("faq.html") > -1) {
					breadBar = "<li><i class=\"icon-book\"></i><a href=\"#\">" + value.name + "</a></li>";
					$breadBar.append(breadBar);
				}
			} else if (level == 2) {
				// console.log(value.parent.menuId);
				$("#" + value.parent.menuId).addClass("active open");
				breadBar = "<li><i class=\"icon-home home-icon\"></i><a href=\"/wechat/pages/admin/index.html\">" + indexName + "</a></li>";
				breadBar = breadBar + "<li><a href=\"#\">" + value.parent.name + "</a></li>";
				breadBar = breadBar + "<li class=\"active\">" + value.name + "</li>";
				$breadBar.append(breadBar);
			}
		}
	});
}

/**
 * 更加字典类型别名获取字典信息
 * @param typeAliasName：字典类型别名，可以自定义，如果系统数据没有的话，但是要保持一致
 */
function getDictInfo(typeAliasName){
	var url="/wechat/sys/dict/getDictInfo.action?typeAliasName="+typeAliasName;
	var data=ajaxGetData(url);
	if(null!=data){
		return data;
	}
}

/**
 * 获取界面操作菜单
 */
function getTextOpBtn() {
	// console.log($("#toolbar").val());
	if (isValidObj($("#toolbar"))) {
		var showUrl = "/wechat/sys/init/showTextOpBtn.action";
		var data = ajaxGetData(showUrl);
		$("#toolbar").html(data);
	}
}

/**
 * 获取当前用户信息
 */
function getUserInfo() {
	var url = "/wechat/sys/userInfo/getUserInfo.action";
	var data = ajaxGetData(url);
	// console.log(data.wechat);
	var currentUrl = window.location.href;// 当前页面的全路径

	// console.log(data.role&&currentUrl.indexOf("index.html")>-1);
	if (currentUrl.indexOf("index.html") > -1) {
//		var orderUrl = "/wechat/purchaseOrder/autoGetOrder.action";
//		$("#dg_table").datagrid({
//			url : orderUrl
//		});
//		$("#showMsgTotal").empty();
//		$("#showMsgTip .dropdown-header").empty();
	}
	return data;
}


// 初始化页面的一些内容
$(function() {
	loadUserMenu();

	// 显示日期和时间
	$('#time_hak').html(getCurrentTime()).css({"width":"40%"});
	
	setInterval(function() {
		$('#time_hak').html(getCurrentTime());
	}, 1000 * 60);
	
	initMenu();// 初始化页面导航

	getTextOpBtn();// 添加页面操作按钮

	var userInfo = getUserInfo();
	// autoGetOrder(userInfo);

	
	// 如果用户已经填写好注册信息
	if (userInfo) {
		// 系统标题
		
	}
	if(userInfo.groupAliasName=="companyGroup"){//如果是企业登陆，就显示企业名称
		$("#userLoadName").append(userInfo.cmpy.cmpyName);
		$("#sysBrand").attr("href", "/wechat/pages/admin/index.html");
		$("#sysBrand small").append("企业管理中心");
	}
	else if(userInfo.groupAliasName=="editorGroup"){//如果是编辑者登陆，就显示编辑者名称
		$("#userLoadName").append(userInfo.editor.editorName);
		$("#sysBrand").attr("href", "/wechat/pages/admin/index.html");
		$("#sysBrand small").append("编辑者中心");
	}
	else{//其他，就直接显示用户名
		$("#userLoadName").append(userInfo.userName);
		$("#sysBrand").attr("href", "/wechat/pages/admin/index.html");
		$("#sysBrand small").append("新媒体管理中心");
	}
//	setInterval(function() {
//		autoGetOrder(userInfo);
//	}, 1000 * 60 * 10);// 十分钟请求一次

	$("#logout").click(function() {
		var url = "/wechat/login/logout.action";
		var data = ajaxGetData(url);
		console.log(data);
		if (data.status == "Y") {
			window.location = "/wechat/login.html";
		}
	});

	$("#checkAllMsg").click(function() {
		$(this).empty();
		$("#showMsgTotal").empty();
		$("#showMsgTip .dropdown-header").empty();
//		if (userInfo.userPrivGroup != "receiverGroup") {
//			window.location.href = "/wechat/pages/admin/index.html";
//		}
	});

	
	

	// 订单查询日期条件显示
//	showOrderQryDate(userInfo);

});



function showOrderQryDate(userInfo) {
	if (userInfo.userPrivGroup == "supplierGroup") {
		$(".auditorQryDate").addClass("hide");
		$(".cmpyQryDate").addClass("hide");
		$(".noSuplOp").addClass("hide");
	} else if (userInfo.userPrivGroup == "companyGroup") {
		$(".auditorQryDate").addClass("hide");
		$(".suplQryDate").addClass("hide");
		$(".recvQryDate").addClass("hide");

	} else if (userInfo.userPrivGroup == "systemResGroup" || userInfo.userPrivGroup == "orderCheckerGroup") {
		$(".cmpyQryDate").addClass("hide");
		$(".suplQryDate").addClass("hide");
		$(".recvQryDate").addClass("hide");

	} else if (userInfo.userPrivGroup == "receiverGroup") {
		$(".noRcpterId").addClass("hide");
		$(".auditorQryDate").addClass("hide");
		$(".cmpyQryDate").addClass("hide");

	} else {
		$(".cmpyQryDate").addClass("hide");
		$(".suplQryDate").addClass("hide");
		$(".auditorQryDate").addClass("hide");
	}
}
