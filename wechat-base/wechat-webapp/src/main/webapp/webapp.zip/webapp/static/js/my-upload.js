// JavaScript Document
;
(function($) {
	$.fn.life_upload = function(options) {
		$.fn.life_upload.defaults = {
			url : "",
			isOnceAll : false,
			queueId : 'queue',
			acceptName : "files",
			autoUpload : false,
			maxSize : 30,
			maxTotal : 3
		}

		var opts = $.extend({}, $.fn.life_upload.defaults, options);
		var $this = $(this);

		var realTotal = 0;
		var realSize = 0;
		var allData = new FormData();
		$this.change(function() {
					var files = [];
					$.each($(this).prop("files"), function(k, v) {
								var name = v['name'];
								var size = v['size'] / 1024;
								
								realTotal = realTotal + 1;
								realSize = realSize + size;
								var formdata = new FormData();
								if (realTotal > opts.maxTotal) {
									var tips = "<span style='color:red;'>文件只能上传前"+ opts.maxTotal + "个</span>";
									var file = "<tr><td colspan=\"2\">" + tips+ "</td></tr>";
									$("table .files").append(file);
									$this.unbind("change");

								} else if (realSize > (opts.maxSize * 1024)) {
									var tips = "<span style='color:red;'>文件最大只能上传"+ opts.maxSize + "M</span>";
									var file = "<tr><td colspan=\"2\">" + tips+ "</td></tr>";
									$("table .files").append(file);
									$this.unbind("change");

								} else {
									formdata.append(opts.acceptName, v);
									allData.append(opts.acceptName, v);
									var file = "<tr><td>" + name + "</td><td>"+ size.toFixed(2) + "K</td></tr>";
									$("table .files").append(file);
									files.push(formdata);
								}
							});

					if (opts.autoUpload === true) {
						if (opts.isOnceAll === true) {
							//alert("onceAll" + $.toJSON(allData));
							$("#" + opts.queueId).children("span,br").remove();
							send(opts.url,allData);
						} else {
							for (var i = 0; i < files.length; i++) {
								//alert($.toJSON(files[i]));
								send(opts.url,files[i]);
							}
						}

					}

				});

		function send(url, data) {
			$.ajax({
						type : "POST",
						contentType : false,
						url : url,
						cache : false,
						data : (data),
						async : false,
						processData : false,
						success : function(data) {
							alert("OK");
						},
						error : function(data) {
							alert("NO!");
						}
					});
		}

		return this;
	}

})(jQuery);
