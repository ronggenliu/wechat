var Animate = { 
obj : null, 
itime : 0, 
flag : 1, 
maxHeight : 0, 
_$ : function(id){ 
return "string" == typeof(id) ? document.getElementById(id) : id; 
}, 
slideDown : function(){ 

if(parseInt(this.obj.style.height) > this.maxHeight){ 
this.flag = 0; 
return 
}; 

this.obj.style.height = parseInt(this.obj.style.height) + 1 + 'px'; 
setTimeout("Animate.slideDown()",this.itime); 
}, 
slideUp: function(){ 
if(parseInt(this.obj.style.height) < 1){ 
this.flag = 1; return 
}; 
this.obj.style.height = parseInt(this.obj.style.height) - 1 + 'px'; 
var repeat = "Animate.slideUp()"; 
setTimeout(repeat,this.itime); 
}, 
slide : function(objid,itime){ 
this.obj = this._$(objid); 
this.itime = itime; 


if(this.flag){ 
this.maxHeight = this.maxHeight ? this.maxHeight :parseInt(this.obj.style.height); 
this.obj.style.display = "block"; 
this.obj.style.height = "0px"; 
this.slideDown(); 
} 
else { 
this.slideUp(); 
} 
}, 
fadeIn : function(objid,itime){ 
this.obj = this._$(objid); 
this.itime = itime; 
var that = this; 
this.maxHeight =parseInt( this.obj.style.height); 
var i = 100; 
var timer = setInterval(function(){ 
that.obj.style.cssText ="filter :alpha(opacity=" + i + ");-moz-opacity:"+i*0.01+";opacity: "+i*0.01+";height:"+that.maxHeight+"px;"; 
i--; 

if(i == 0) clearInterval(timer); 
},that.itime); 
}, 
fadeOut : function(objid,itime){ 
this.obj = this._$(objid); 
this.itime = itime; 
var that = this; 
this.maxHeight =parseInt( this.obj.style.height); 
var i = 0; 
var timer = setInterval(function(){ 
that.obj.style.cssText ="filter :alpha(opacity=" + i + ");-moz-opacity:"+i*0.01+";opacity: "+i*0.01+";height:"+that.maxHeight+"px;"; 
i++; 
if(i ==100) clearInterval(timer); 
},that.itime); 
} 
} 