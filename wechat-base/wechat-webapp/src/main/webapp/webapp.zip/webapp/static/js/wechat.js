var redirect_uri = encodeURIComponent(window.location.href);
/**js 网页授权页面*/
var getCode = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxb1b9b3dbf703cdbd&redirect_uri="
		+ redirect_uri + "&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";








